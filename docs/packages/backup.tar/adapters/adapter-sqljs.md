# Unmaintained: this plugin used to live in @elizaos/core. It needs a maintainer.
