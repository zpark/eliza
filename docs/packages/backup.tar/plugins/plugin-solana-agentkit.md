# Plugin Solana AgentKit

A Solana integration plugin for AgentKit that enables interaction with the Solana blockchain.

## Features

- Solana wallet integration
- Transaction handling
- Account management
- RPC connection management
- Solana program interactions
