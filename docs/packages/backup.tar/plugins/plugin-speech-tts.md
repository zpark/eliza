# service-speech-tts

TTS transcription service with OpenAI + ElevenLabs

